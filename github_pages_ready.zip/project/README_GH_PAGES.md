# GitHub Pages Deployment (Vite + React)

This repo is configured to auto-deploy to GitHub Pages.

## Steps
1. Create a **new GitHub repo** and push this folder's contents to it.
2. Go to **Settings → Pages** and set:
   - **Source:** GitHub Actions
3. Push to `main` branch. The included workflow (`.github/workflows/pages.yml`) will:
   - Install deps
   - Build with Vite
   - Publish `dist/` to GitHub Pages

> Vite `base` is set to `./` (in `vite.config.ts`) so it works on project pages.

