# Vintiy Dropshipping Tool

AliExpress ürünlerini otomatik olarak WordPress/WooCommerce sitenize aktaran ücretsiz araç.

## Özellikler
- ✅ AliExpress entegrasyonu
- ✅ Otomatik Azerbaycan Türkçesi çevirisi  
- ✅ WordPress/WooCommerce uyumlu
- ✅ Tamamen ücretsiz

## Kullanım
1. AliExpress ürün linkini kopyalayın
2. Uygulamaya yapıştırın
3. Otomatik çeviri ile ürün bilgilerini alın
4. JSON dosyasını indirin
5. WordPress'e aktarın

## Deployment
Bu proje GitHub Pages ile otomatik deploy edilir.

## Geliştirici
Vintiy.com için özel geliştirilmiştir.