import React, { useState } from 'react';
import { Search, Download, Globe, ShoppingCart, Package, Zap } from 'lucide-react';

interface Product {
  id: string;
  title: string;
  titleAz: string;
  price: string;
  images: string[];
  description: string;
  descriptionAz: string;
  variations: any[];
  url: string;
}

function App() {
  const [productUrl, setProductUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [product, setProduct] = useState<Product | null>(null);
  const [error, setError] = useState('');

  // Azerbaycan Türkçesi çeviri fonksiyonu
  const translateToAzerbaijani = async (text: string): Promise<string> => {
    // Basit çeviri örnekleri - gerçek projede Google Translate API kullanabilirsiniz
    const translations: { [key: string]: string } = {
      'Women': 'Qadın',
      'Men': 'Kişi',
      'Fashion': 'Moda',
      'Dress': 'Paltar',
      'Shirt': 'Köynək',
      'Shoes': 'Ayaqqabı',
      'Bag': 'Çanta',
      'Watch': 'Saat',
      'Phone': 'Telefon',
      'Case': 'Qab',
      'Beauty': 'Gözəllik',
      'Home': 'Ev',
      'Garden': 'Bağ',
      'Sports': 'İdman',
      'Toys': 'Oyuncaq',
      'Electronics': 'Elektronika',
      'Jewelry': 'Zərgərlik',
      'Accessories': 'Aksesuarlar'
    };

    let translatedText = text;
    Object.entries(translations).forEach(([en, az]) => {
      translatedText = translatedText.replace(new RegExp(en, 'gi'), az);
    });

    return translatedText;
  };

  // AliExpress ürün bilgilerini çek
  const fetchProductData = async (url: string) => {
    setLoading(true);
    setError('');
    
    try {
      // Bu örnekte mock data kullanıyoruz
      // Gerçek projede AliExpress API veya web scraping kullanabilirsiniz
      
      // URL'den ürün ID'sini çıkar
      const productId = url.match(/\/(\d+)\.html/)?.[1] || Math.random().toString();
      
      // Mock ürün verisi
      const mockProduct = {
        id: productId,
        title: "Women's Fashion Summer Dress Casual Elegant Style",
        price: "$15.99 - $25.99",
        images: [
          "https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg",
          "https://images.pexels.com/photos/1462637/pexels-photo-1462637.jpeg",
          "https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg"
        ],
        description: "High quality summer dress made from premium cotton blend. Perfect for casual and elegant occasions. Available in multiple colors and sizes.",
        variations: [
          { color: "Red", size: "S", price: "$15.99" },
          { color: "Red", size: "M", price: "$16.99" },
          { color: "Blue", size: "S", price: "$15.99" },
          { color: "Blue", size: "M", price: "$16.99" }
        ],
        url: url
      };

      // Azerbaycan Türkçesine çevir
      const titleAz = await translateToAzerbaijani(mockProduct.title);
      const descriptionAz = await translateToAzerbaijani(mockProduct.description);

      const productData: Product = {
        ...mockProduct,
        titleAz,
        descriptionAz
      };

      setProduct(productData);
    } catch (err) {
      setError('Ürün bilgileri alınırken hata oluştu. Lütfen geçerli bir AliExpress linki girin.');
    } finally {
      setLoading(false);
    }
  };

  // WordPress'e ürün ekle
  const exportToWordPress = () => {
    if (!product) return;

    const wpProductData = {
      name: product.titleAz,
      type: 'simple',
      regular_price: product.price.split(' - ')[0].replace('$', ''),
      description: product.descriptionAz,
      short_description: product.descriptionAz.substring(0, 100) + '...',
      images: product.images.map(img => ({ src: img })),
      categories: [{ name: 'Dropshipping' }],
      meta_data: [
        { key: '_aliexpress_url', value: product.url },
        { key: '_product_id', value: product.id }
      ]
    };

    // JSON formatında indir
    const dataStr = JSON.stringify(wpProductData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `product-${product.id}.json`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <Package className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Vintiy Dropshipping</h1>
                <p className="text-sm text-gray-600">AliExpress → WordPress Otomatik İçe Aktarma</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Globe className="w-4 h-4" />
              <span>Azerbaycan Türkçesi Desteği</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Özellikler */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border">
            <div className="flex items-center space-x-3 mb-3">
              <Zap className="w-8 h-8 text-yellow-500" />
              <h3 className="font-semibold text-gray-900">Hızlı İçe Aktarma</h3>
            </div>
            <p className="text-gray-600 text-sm">AliExpress linkini yapıştır, otomatik olarak ürün bilgilerini çek</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border">
            <div className="flex items-center space-x-3 mb-3">
              <Globe className="w-8 h-8 text-blue-500" />
              <h3 className="font-semibold text-gray-900">Otomatik Çeviri</h3>
            </div>
            <p className="text-gray-600 text-sm">Ürün başlık ve açıklamaları Azerbaycan Türkçesine çevrilir</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border">
            <div className="flex items-center space-x-3 mb-3">
              <ShoppingCart className="w-8 h-8 text-green-500" />
              <h3 className="font-semibold text-gray-900">WordPress Entegrasyonu</h3>
            </div>
            <p className="text-gray-600 text-sm">Direkt olarak WooCommerce mağazanıza aktarın</p>
          </div>
        </div>

        {/* Ana Form */}
        <div className="bg-white rounded-xl shadow-sm border p-8">
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Ürün İçe Aktarma</h2>
            <p className="text-gray-600">AliExpress ürün linkini aşağıya yapıştırın</p>
          </div>

          <div className="flex space-x-4 mb-6">
            <div className="flex-1">
              <input
                type="url"
                value={productUrl}
                onChange={(e) => setProductUrl(e.target.value)}
                placeholder="https://www.aliexpress.com/item/..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
            <button
              onClick={() => fetchProductData(productUrl)}
              disabled={loading || !productUrl}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              <Search className="w-5 h-5" />
              <span>{loading ? 'Yükleniyor...' : 'Ürünü Çek'}</span>
            </button>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {/* Ürün Önizleme */}
          {product && (
            <div className="border-t pt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Ürün Önizleme</h3>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Ürün Görselleri */}
                <div>
                  <div className="grid grid-cols-2 gap-4">
                    {product.images.map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`Ürün ${index + 1}`}
                        className="w-full h-48 object-cover rounded-lg border"
                      />
                    ))}
                  </div>
                </div>

                {/* Ürün Bilgileri */}
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Orijinal Başlık (İngilizce)</h4>
                    <p className="text-gray-700 bg-gray-50 p-3 rounded-lg">{product.title}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Çevrilmiş Başlık (Azerbaycan Türkçesi)</h4>
                    <p className="text-gray-700 bg-blue-50 p-3 rounded-lg font-medium">{product.titleAz}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Fiyat</h4>
                    <p className="text-2xl font-bold text-green-600">{product.price}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Açıklama (Azerbaycan Türkçesi)</h4>
                    <p className="text-gray-700 bg-blue-50 p-3 rounded-lg">{product.descriptionAz}</p>
                  </div>

                  {/* Varyasyonlar */}
                  {product.variations.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Varyasyonlar</h4>
                      <div className="space-y-2">
                        {product.variations.map((variation, index) => (
                          <div key={index} className="flex justify-between items-center bg-gray-50 p-2 rounded">
                            <span>{variation.color} - {variation.size}</span>
                            <span className="font-medium">{variation.price}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* WordPress'e Aktar Butonu */}
                  <button
                    onClick={exportToWordPress}
                    className="w-full px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center justify-center space-x-2"
                  >
                    <Download className="w-5 h-5" />
                    <span>WordPress'e Aktar (JSON İndir)</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Kullanım Rehberi */}
        <div className="mt-8 bg-white rounded-xl shadow-sm border p-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Nasıl Kullanılır?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-indigo-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-indigo-600 font-bold">1</span>
              </div>
              <h4 className="font-medium mb-2">AliExpress Linkini Kopyala</h4>
              <p className="text-sm text-gray-600">Satmak istediğiniz ürünün AliExpress linkini kopyalayın</p>
            </div>
            
            <div className="text-center">
              <div className="bg-indigo-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-indigo-600 font-bold">2</span>
              </div>
              <h4 className="font-medium mb-2">Ürünü İçe Aktar</h4>
              <p className="text-sm text-gray-600">Link'i yapıştırın ve otomatik çeviri ile ürün bilgilerini alın</p>
            </div>
            
            <div className="text-center">
              <div className="bg-indigo-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-indigo-600 font-bold">3</span>
              </div>
              <h4 className="font-medium mb-2">WordPress'e Ekle</h4>
              <p className="text-sm text-gray-600">JSON dosyasını indirin ve WooCommerce'e aktarın</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;